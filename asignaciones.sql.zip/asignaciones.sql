-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 08-04-2025 a las 17:33:43
-- Versión del servidor: 8.0.30
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `asignaciones`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignar`
--

CREATE TABLE `asignar` (
  `IDasignar` int NOT NULL,
  `IDprofesor` int NOT NULL,
  `IDgrupo` int NOT NULL,
  `IDforestal` int DEFAULT NULL,
  `IDinformatica` int DEFAULT NULL,
  `IDgestion` int DEFAULT NULL,
  `IDsemestre` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `asignar`
--

INSERT INTO `asignar` (`IDasignar`, `IDprofesor`, `IDgrupo`, `IDforestal`, `IDinformatica`, `IDgestion`, `IDsemestre`) VALUES
(14, 38, 14, 42, NULL, NULL, 2),
(18, 1, 2, NULL, 17, NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupos`
--

CREATE TABLE `grupos` (
  `IDgrupo` int NOT NULL,
  `grupo` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `grupos`
--

INSERT INTO `grupos` (`IDgrupo`, `grupo`) VALUES
(1, '1C'),
(2, '1G'),
(3, '2A'),
(4, '2B'),
(5, '2G'),
(6, '2H'),
(7, '2U'),
(8, '2V'),
(9, '3G'),
(10, '3R'),
(11, '4A'),
(12, '4B'),
(13, '4G'),
(14, '6A'),
(15, '6G'),
(16, '6U'),
(17, '6V'),
(18, '8A'),
(19, '8B'),
(20, '8C'),
(21, '8G'),
(22, '8U');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ing_forestal`
--

CREATE TABLE `ing_forestal` (
  `IDforestal` int NOT NULL,
  `materiaf` varchar(100) NOT NULL,
  `credhtf` int NOT NULL,
  `credhpf` int NOT NULL,
  `creditosf` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `ing_forestal`
--

INSERT INTO `ing_forestal` (`IDforestal`, `materiaf`, `credhtf`, `credhpf`, `creditosf`) VALUES
(1, 'Algebra Lineal', 3, 2, 5),
(2, 'Fundamentos de Investigación', 2, 2, 4),
(3, 'Tecnologías de la Información y las Comunicaciones', 1, 2, 3),
(4, 'Taller de Ética', 0, 4, 4),
(5, 'Botánica General\r\n', 2, 2, 4),
(6, 'Bioquímica\r\n', 2, 3, 5),
(7, 'Cálculo Diferencial\r\n', 3, 2, 5),
(8, 'Administración\r\n', 2, 2, 4),
(9, 'Física\r\n', 2, 3, 5),
(10, 'Desarrollo Humano\r\n', 1, 2, 3),
(11, 'Botánica Forestal\r\n', 2, 3, 5),
(12, 'Fisiología\r\n', 2, 3, 5),
(13, 'Cálculo Integral\r\n', 3, 2, 5),
(14, 'Economía Forestal\r\n', 1, 2, 3),
(15, 'Estadística\r\n', 2, 3, 5),
(16, 'Edafología\r\n', 3, 2, 5),
(17, 'Ecología\r\n', 3, 2, 5),
(18, 'Sociología Rura\r\n', 1, 3, 4),
(19, 'Anatomía de la Madera\r\n', 2, 2, 4),
(20, 'Dendrometría\r\n', 2, 3, 5),
(21, 'Investigación de Operaciones\r\n', 2, 3, 5),
(22, 'Muestreo y Regresión\r\n', 2, 2, 4),
(23, 'Política y Legislación Forestal\r\n', 2, 2, 4),
(24, 'Extensión y Divulgación\r\n', 2, 2, 4),
(25, 'Viveros Forestales\r\n', 2, 2, 4),
(26, 'Introducción a los Sistemas de Información Geográfica\r\n', 2, 3, 5),
(27, 'Manejo del Fuego\r\n', 2, 2, 4),
(28, 'Silvicultura\r\n', 2, 2, 4),
(29, 'Diseños Experimentales\r\n', 1, 2, 3),
(30, 'Sanidad Forestal\r\n', 1, 2, 3),
(31, 'Desarrollo Sustentable\r\n', 2, 3, 5),
(32, 'Plantaciones Forestales\r\n', 2, 2, 4),
(33, 'Sistemas de Información Geográfica\r\n', 2, 3, 5),
(34, 'Epidometría\r\n', 2, 3, 5),
(35, 'Rehabilitación de Ecosistemas Forestales\r\n', 1, 3, 4),
(36, 'Tecnología de la Madera\r\n', 2, 2, 4),
(37, 'Genética Forestal\r\n', 2, 2, 4),
(38, 'Hidrología\r\n', 2, 2, 4),
(39, 'Evaluación de Recursos Forestales\r\n', 2, 3, 5),
(40, 'Taller de Investigación I\r\n', 0, 4, 4),
(41, 'Manejo Forestal\r\n', 2, 3, 5),
(42, 'Abastecimiento Forestal\r\n', 2, 3, 5),
(43, 'Industrias Forestales\r\n', 2, 3, 5),
(44, 'Criterios e Indicadores de Sustentabilidad\r\n', 2, 2, 4),
(45, 'Mercadotecnia\r\n', 2, 2, 4),
(46, 'Taller de Investigación II\r\n', 0, 4, 4),
(47, 'Evaluación de Impactos Ambientales\r\n', 2, 3, 5),
(48, 'Taller de Formulación y Evaluación de Proyectos\r\n', 2, 2, 4),
(49, 'Residencia Profesional\r\n', 0, 10, 10),
(50, 'Especialidad', 0, 25, 25),
(51, 'Actividades Complementarias', 0, 5, 5),
(52, 'Servicio Social', 0, 10, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ing_gestion`
--

CREATE TABLE `ing_gestion` (
  `IDgestion` int NOT NULL,
  `materiag` varchar(100) NOT NULL,
  `credhtg` int NOT NULL,
  `credhpg` int NOT NULL,
  `creditosg` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `ing_gestion`
--

INSERT INTO `ing_gestion` (`IDgestion`, `materiag`, `credhtg`, `credhpg`, `creditosg`) VALUES
(1, 'Desarrollo Humano GE\r\n', 2, 2, 4),
(2, 'Fundamentos de gestión empresarial\r\n', 3, 2, 5),
(3, 'Fundamentos de Física \r\n', 3, 3, 5),
(4, 'Fundamentos de química \r\n', 3, 2, 5),
(5, 'Actividades complementarias \r\n', 0, 5, 5),
(6, 'Software de aplicación ejecutivo \r\n', 1, 4, 5),
(7, 'Contabilidad orientada a los negocios \r\n', 2, 3, 5),
(8, 'Dinámica social \r\n', 2, 2, 4),
(9, 'Legislación laboral\r\n', 3, 1, 4),
(10, 'Marco Legal de las organizaciones \r\n', 2, 2, 4),
(11, 'Probabilidad y Estadistica Descriptiva \r\n', 2, 3, 5),
(12, 'Costos Empresariales Ged\r\n', 2, 3, 5),
(13, 'Habilidades Directivas I\r\n', 2, 2, 4),
(14, 'Economía Empresarial\r\n', 3, 2, 5),
(15, 'Ingeniería Económica \r\n', 3, 2, 5),
(16, 'Estadística Inferencial I\r\n', 3, 3, 6),
(17, 'Estadística Inferencial I\r\n', 3, 3, 6),
(18, 'Instrumentos de presupuestación empresarial\r\n', 2, 3, 5),
(19, 'Habilidades Directivas II\r\n', 2, 2, 4),
(20, 'Entorno Macroeconómico\r\n', 3, 2, 5),
(21, 'Investigación de Operaciones GE\r\n', 3, 2, 5),
(22, 'Finanzas de las Organizaciones \r\n', 3, 2, 5),
(23, 'Estadística Inferencial II\r\n', 3, 3, 6),
(24, 'Ingeniería de Procesos \r\n', 3, 2, 5),
(25, 'Gestión del Capital Humano\r\n', 3, 3, 6),
(26, 'Mercadotecnia GE\r\n', 3, 2, 5),
(27, 'Administración de la Salud y Seguridad Ocupacional \r\n', 3, 2, 5),
(28, 'El emprendedor y la Innovación \r\n', 2, 3, 5),
(29, 'Gestión de la Producción I\r\n', 2, 2, 4),
(30, 'Diseño Organizacional \r\n', 2, 3, 5),
(31, 'Sistemas de Información de Mercadotecnia \r\n', 2, 3, 5),
(32, 'Calidad Aplicada a la Gestión Empresarial\r\n', 2, 3, 5),
(33, 'Plan de Negocios \r\n', 2, 3, 5),
(34, 'Gestión de la Producción II\r\n', 2, 2, 4),
(35, 'Gestión Estratégica \r\n', 2, 3, 5),
(36, 'Mercadotecnia Electronica \r\n', 1, 4, 5),
(37, 'Servicio Social\r\n', 0, 10, 10),
(38, 'Cadena de Suministros \r\n', 3, 2, 5),
(39, 'Fundamentos de Investigación\r\n', 2, 2, 4),
(40, 'Cálculo Diferencial\r\n', 3, 2, 5),
(41, 'Cálculo Integral\r\n', 3, 2, 5),
(42, 'Taller de Ética\r\n', 0, 4, 4),
(43, 'Algebra Lineal\r\n', 3, 2, 5),
(44, 'Taller de Investigación I\r\n', 0, 4, 4),
(45, 'Desarrollo Sustentable\r\n', 2, 3, 5),
(46, 'Taller de Investigación II\r\n', 0, 4, 4),
(47, 'Residencia Profesional\r\n', 0, 10, 10),
(48, 'Especialidad\r\n', 0, 25, 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ing_informatica`
--

CREATE TABLE `ing_informatica` (
  `IDinformatica` int NOT NULL,
  `materiai` varchar(100) NOT NULL,
  `credhti` int NOT NULL,
  `credhpi` int NOT NULL,
  `creditosi` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `ing_informatica`
--

INSERT INTO `ing_informatica` (`IDinformatica`, `materiai`, `credhti`, `credhpi`, `creditosi`) VALUES
(1, 'Administración para Informática\r\n', 3, 1, 4),
(2, 'Fundamentos de Investigación\r\n', 2, 2, 4),
(3, 'Fundamentos de Programación\r\n', 3, 2, 5),
(4, 'Administración de los Recursos y Función Informática\r\n', 2, 2, 4),
(5, 'Física para Informática\r\n', 2, 3, 5),
(6, 'Programación Orientada a Objetos\r\n', 1, 4, 5),
(7, 'Contabilidad Financiera\r\n', 2, 2, 4),
(8, 'Matemáticas Discretas\r\n', 3, 2, 5),
(9, 'Fundamentos de Sistemas de Información\r\n', 3, 1, 4),
(10, 'Sistemas Electrónicos para Informática\r\n', 2, 2, 4),
(11, 'Estructura de Datos\r\n', 2, 3, 5),
(12, 'Costos Empresariales', 2, 2, 4),
(13, 'Probabilidad y Estadística\r\n', 3, 2, 5),
(14, 'Arquitectura de Computadoras\r\n', 2, 3, 5),
(15, 'Administración y Organización de Datos\r\n', 3, 2, 5),
(16, 'Fundamentos de Telecomunicaciones\r\n', 2, 2, 4),
(17, 'Sistemas Operativos I\r\n', 2, 2, 4),
(18, 'Investigación de Operaciones\r\n', 3, 2, 5),
(19, 'Análisis y Modelado de Sistemas de Información\r\n', 3, 2, 5),
(20, 'Tecnologías e Interfaces de Computadoras\r\n', 2, 2, 4),
(21, 'Fundamentos de Base de Datos\r\n', 3, 2, 5),
(22, 'Redes de Computadoras\r\n', 2, 3, 5),
(23, 'Sistemas Operativos II\r\n', 2, 3, 5),
(24, 'Taller de Legislación Informática\r\n', 2, 1, 3),
(25, 'Desarrollo e Implementación de Sistemas de Información\r\n', 2, 3, 5),
(26, 'Auditoría en Informática\r\n', 3, 1, 4),
(27, 'Taller de Base de Datos\r\n', 0, 4, 4),
(28, 'Interconectividad de Redes\r\n', 2, 4, 6),
(29, 'Desarrollo de Aplicaciones Web\r\n', 2, 3, 5),
(30, 'Calidad en los Sistemas de Información\r\n', 2, 2, 4),
(31, 'Fundamentos de Gestión de Servicios de TI\r\n', 3, 1, 4),
(32, 'Tópicos de Base de Datos\r\n', 3, 2, 5),
(33, 'Administración de Servidores\r\n', 1, 3, 4),
(34, 'Programación en Ambiente Cliente/Servidor\r\n', 3, 2, 5),
(35, 'Taller de Emprendedores\r\n', 2, 3, 5),
(36, 'Estrategias de Gestión de Servicios de TI\r\n', 3, 2, 5),
(37, 'Inteligencia de Negocios\r\n', 3, 2, 5),
(38, 'Desarrollo de Aplicaciones para Dispositivos Móviles\r\n', 1, 4, 5),
(39, 'Seguridad Informática\r\n', 2, 2, 4),
(40, 'Taller de etica\r\n', 0, 4, 4),
(41, 'Calculo diferencial\r\n', 3, 2, 5),
(42, 'Desarrollo sustentable \r\n', 2, 3, 5),
(43, 'Calculo integral\r\n', 3, 2, 5),
(44, 'Algebra lineal\r\n', 3, 2, 5),
(45, 'Taller de Investigación I\r\n', 0, 4, 4),
(46, 'Taller de Investigación II\r\n', 0, 4, 4),
(47, 'Residencia Profesional\r\n', 0, 10, 10),
(48, 'Especialidad\r\n', 0, 25, 25),
(49, 'Servicio Social\r\n', 0, 10, 10),
(50, 'Actividades complementarias \r\n', 0, 5, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesores`
--

CREATE TABLE `profesores` (
  `IDprofesor` int NOT NULL,
  `ApellidoPat` varchar(50) NOT NULL,
  `ApellidoMat` varchar(50) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `limcred` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `profesores`
--

INSERT INTO `profesores` (`IDprofesor`, `ApellidoPat`, `ApellidoMat`, `Nombre`, `limcred`) VALUES
(1, 'AGUIRRE ', 'CALDERÓN ', 'CARLOS ENRIQUE', 5),
(2, 'ALMADER ', 'HERNÁNDEZ', 'MARÍA TERESA ', 15),
(3, 'ÁLVAREZ', 'FAVELA', 'DAVID ORLANDO', 4),
(4, 'CARRERA', 'ESCONTRIAS', 'PAULIN', 8),
(5, 'CASTAÑEDA', 'ÁVILA', 'JAIME', 19),
(6, 'COLÍN ', '', 'JOSÉ GUADALUPE', 15),
(7, 'CORRAL', 'RIVAS', 'SACRAMENTO', 10),
(8, 'DE LA CRUZ ', 'CARRERA ', 'RICARDO', 14),
(9, 'DE LA CRUZ ', 'DE LA CRUZ ', 'JOSÉ ALFREDO', 20),
(10, 'DE LEÓN ', 'GÓMEZ', 'JOSÉ DE JESÚS', 6),
(11, 'DE LA ROSA ', 'TORRES', 'JOSÉ ANGEL', 8),
(12, 'DERÁS ', 'FLORES ', 'JOSÉ RAMÓN ', 10),
(13, 'DERAS ', 'FLORES', 'SARA IVETH', 6),
(14, 'DÍAZ', 'RAMÍREZ', 'BEATRIZ', 17),
(15, 'DOMÍNGUEZ ', 'GÓMEZ', 'TILO GUSTAVO', 15),
(16, 'GUERRERO ', 'DERAS ', 'SERGIO ', 19),
(17, 'GUERRERO ', 'GARAY ', 'VICTOR ARTURO', 15),
(18, 'GURROLA ', 'AMAYA', 'JOSE GONZALO ', 16),
(19, 'GUTIÉRREZ ', 'DEL CAMPO', 'DANIEL ALBERTO', 14),
(20, 'HARO', 'PACHECO', 'MIGUEL ÁNGEL', 13),
(21, 'HERNÁNDEZ ', '', 'FRANCISCO JAVIER', 13),
(22, 'HERNÁNDEZ ', 'RIOS', 'ROSA', 4),
(23, 'JIMÉNEZ ', 'CORCHADO ', 'ELIZANDRO', 20),
(24, 'LUJÁN ', 'SOTO', 'JOSÉ ENCARNACIÓN ', 5),
(25, 'LUJÁN', 'ESPINOZA', 'ALDO ALEJANDRO', 4),
(26, 'MALDONADO', 'AYALA', 'DAVID', 5),
(27, 'MARTINEZ', 'QUIÑONES', 'JOSÉ ALFREDO', 15),
(28, 'MEDRANO ', 'SÁNCHEZ ', 'HÉCTOR ARMANDO', 8),
(29, 'MELCHOR', 'OJEDA', 'MARÍA DE LOURDES', 16),
(30, 'MEZA', 'ARAGÓN ', 'JORGE', 10),
(31, 'MEZA', 'LÓPEZ ', 'PEDRO', 20),
(32, 'NÁJERA', 'FRÍAS', 'JAVIER', 10),
(33, 'NÁJERA', 'LUNA', 'JUAN ABEL', 9),
(34, 'PALOMARES ', 'ADAME ', 'ALMA VERÓNICA ', 6),
(35, 'PÁEZ', 'LERMA', 'IBETH GUADALUPE', 4),
(36, '', '', 'PENDIENTE', 0),
(37, 'RADILLA', 'CASTREJÓN', 'JORGE LUIS', 4),
(38, 'REYES', 'BASULTO', 'DANIEL', 15),
(39, 'RODRIGUEZ', 'RETA', 'ISAAC', 10),
(40, 'SALINAS', 'AVENDAÑO', 'MARIO MARTIN', 14),
(41, 'SILVA ', 'ROBLES ', 'MIGUEL', 8),
(42, 'SOLÍS', 'GONZÁLEZ', 'SANTIAGO', 14),
(43, 'TORRES', 'PÉREZ', 'JOSÉ JESÚS', 20),
(44, 'VARGAS', 'LARRETA', 'BENEDICTO', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `semestre`
--

CREATE TABLE `semestre` (
  `IDsemestre` int NOT NULL,
  `meses` varchar(100) NOT NULL,
  `año` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `semestre`
--

INSERT INTO `semestre` (`IDsemestre`, `meses`, `año`) VALUES
(1, 'Ene-Jun', 2025),
(2, 'Ago-Dic', 2025),
(3, 'Ene-Jun', 2026);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `IDuser` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `rol` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`IDuser`, `username`, `password`, `rol`) VALUES
(4, 'prueba2', '$2y$10$s0AaJ658SqFMrDgCLEYkv..ULuNJ.hhhi7ZQQMrv5ctfnz/639mPS', 'admin'),
(6, 'pruebasa', '$2y$10$INMfme2HxF0ywxx0pc7QLuJJnBzpYeGJjqWQ1cedkTE2PyqfF7QkK', 'usuario');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asignar`
--
ALTER TABLE `asignar`
  ADD PRIMARY KEY (`IDasignar`),
  ADD KEY `IDprofesor` (`IDprofesor`,`IDgrupo`,`IDforestal`,`IDinformatica`,`IDgestion`),
  ADD KEY `IDgrupo` (`IDgrupo`),
  ADD KEY `IDinformatica` (`IDinformatica`),
  ADD KEY `IDforestal` (`IDforestal`),
  ADD KEY `IDgestion` (`IDgestion`),
  ADD KEY `IDsemestre` (`IDsemestre`);

--
-- Indices de la tabla `grupos`
--
ALTER TABLE `grupos`
  ADD PRIMARY KEY (`IDgrupo`);

--
-- Indices de la tabla `ing_forestal`
--
ALTER TABLE `ing_forestal`
  ADD PRIMARY KEY (`IDforestal`);

--
-- Indices de la tabla `ing_gestion`
--
ALTER TABLE `ing_gestion`
  ADD PRIMARY KEY (`IDgestion`);

--
-- Indices de la tabla `ing_informatica`
--
ALTER TABLE `ing_informatica`
  ADD PRIMARY KEY (`IDinformatica`);

--
-- Indices de la tabla `profesores`
--
ALTER TABLE `profesores`
  ADD PRIMARY KEY (`IDprofesor`);

--
-- Indices de la tabla `semestre`
--
ALTER TABLE `semestre`
  ADD PRIMARY KEY (`IDsemestre`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`IDuser`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asignar`
--
ALTER TABLE `asignar`
  MODIFY `IDasignar` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `grupos`
--
ALTER TABLE `grupos`
  MODIFY `IDgrupo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `ing_forestal`
--
ALTER TABLE `ing_forestal`
  MODIFY `IDforestal` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT de la tabla `ing_gestion`
--
ALTER TABLE `ing_gestion`
  MODIFY `IDgestion` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT de la tabla `ing_informatica`
--
ALTER TABLE `ing_informatica`
  MODIFY `IDinformatica` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT de la tabla `profesores`
--
ALTER TABLE `profesores`
  MODIFY `IDprofesor` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT de la tabla `semestre`
--
ALTER TABLE `semestre`
  MODIFY `IDsemestre` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `IDuser` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `asignar`
--
ALTER TABLE `asignar`
  ADD CONSTRAINT `asignar_ibfk_1` FOREIGN KEY (`IDprofesor`) REFERENCES `profesores` (`IDprofesor`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `asignar_ibfk_2` FOREIGN KEY (`IDgrupo`) REFERENCES `grupos` (`IDgrupo`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `asignar_ibfk_3` FOREIGN KEY (`IDinformatica`) REFERENCES `ing_informatica` (`IDinformatica`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `asignar_ibfk_4` FOREIGN KEY (`IDforestal`) REFERENCES `ing_forestal` (`IDforestal`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `asignar_ibfk_5` FOREIGN KEY (`IDgestion`) REFERENCES `ing_gestion` (`IDgestion`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `asignar_ibfk_6` FOREIGN KEY (`IDsemestre`) REFERENCES `semestre` (`IDsemestre`) ON DELETE CASCADE ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
